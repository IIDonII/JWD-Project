public class Jar {

  public static void main(String[] args) {
    Game game = new Game ("",0,"",0,4,200);
    Prompter prompter = new Prompter(game);
    prompter.startGame();
   
       
  }
}